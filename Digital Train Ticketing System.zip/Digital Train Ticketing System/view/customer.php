<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/customer.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

</head>
<body>
<?php

// define variables and set to empty values
 $routeErr = $dateErr = $classErr = $passengersErr = "";
 $route = $date = $class = $passengers = "";


 if ($_SERVER["REQUEST_METHOD"] == "POST") {  
  if (empty($_POST["route"])) {
    $routeErr = "Route required";
  } else {
    $route = test_input($_POST["route"]);
  }

  if (empty($_POST["date"])) {
    $dateErr = "Date is required";
  } else {
    $date = test_input($_POST["date"]);
  }
  if (empty($_POST["class"])) {
    $classErr = "class is required";
  } else {
    $class = test_input($_POST["class"]);
  }
  if (empty($_POST["passengers"])) {
    $passengersErr = "passengers required";
  } else {
    $passengers = test_input($_POST["passengers"]);
  }
  
}


?>

<div id="header">
<h1>Digital Train Ticketing System</h1>
</div>

<div id="topnav">


<a href="home.php">Home</a>
<a href="login.php">Login</a>
<a href="profile.php">Profile</a>
<a href="dashboard.php">Dashboard</a>
<a href="logout.php">Logout</a>
 
</div>

</div>
<form action="confirmpurchase.php" method='post'  >
		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					<fieldset>
						<legend>
							<strong>Home</strong><br/>
							


						</legend>
<div id="contact-title">
  <h1>Purchase Ticket</h1>
</div>
<p><span class="error"><b>* Required field</b></span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  <b>Route:</b><br>
  <select name="route" id="route">
  <option value="">From</option>
  <option value="Dhaka">Dhaka</option>
  <option value="Chittagang">Chittagang</option>
  <option value="Rajshahi">Rajshahi</option>
  <option value="Barishal">Barishal</option>
  <option value="Noakhali">Noakhali</option>
  <option value="Khulna">Khulna</option>
  <option value="Sylhet">Sylhet</option>
</select>
<span class="error">* <?php echo $routeErr;?></span>
 


<select name="route" id="route">
 <option value="">To</option>
 <option value="Dhaka">Dhaka</option>
  <option value="Chittagang">Chittagang</option>
  <option value="Rajshahi">Rajshahi</option>
  <option value="Barishal">Barishal</option>
  <option value="Noakhali">Noakhali</option>
  <option value="Khulna">Khulna</option>
  <option value="Sylhet">Sylhet</option>
</select>


  <span class="error">* <?php echo $routeErr;?></span>
  <br><br>

  <b>Date:</b><br>
 
  <input type="date" id="date" name="date">
  <span class="error">* <?php echo $dateErr;?></span>
  <br><br>

  <b>Class:</b><br>
  <select name="class" id="class">
  <option value="">1st Class</option>
  <option value="1st Class">1st Class</option>
  <option value="2nd Class">2nd Class</option>
</select>
<span class="error">* <?php echo $classErr;?></span>
<br><br>

<b>Passengers:</b><br>
  <select name="passengers" id="passengers">
  <option value="">Adult</option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<span class="error">* <?php echo $passengersErr;?></span>
<select name="passengers" id="passengers">
  <option value="">Child</option>
  <option value="0">0</option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<span class="error">* <?php echo $passengersErr;?></span>
<br><br>
  
  
       
  <input type="submit" name="Purchase" value="Purchase">
  
     
 
     

						
					</fieldset>
				</form>

                <div id="foot">
<b>Contact</b><br>Let us book your next trip!
<br>Bangladesh<br><br><i class="fas fa-phone"></i> Help Line No: 2021
</div>


</body>
</html>
