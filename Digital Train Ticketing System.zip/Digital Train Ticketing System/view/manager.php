<!DOCTYPE html>
<html>
<head>
	<title>Digital Train Ticketing System</title>
</head>
<body>
	<table border="1" cellspaceing="0px" align="center" width="900px">
		<tr height="50px">
			
		    
		    <th colspan="3">
		    	
		    	<a href="home.php" >Home</a>|
		    	<a href="login.php">Login</a>|
		    	<a href="registration.php">Registration</a>
		    </th>
		    
   
		   
		</tr>

		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					<fieldset>
						<legend>
							<strong>Manager</strong><br/>
							


						</legend>

						


<form action="manager.php" method='post'  >
    <table style="width:50%" >
        
    <tr>
            <td>Name  :</td>
            <td>MD. abc</td>
        </tr>

        <tr>
            <td>ID  :</td>
            <td>2585258</td>
        </tr>

        <tr>
            <td>Joining Date  :</td>
            <td>22-06-2021</td>
        </tr>
       
 <tr>
     <tr>
     <td><span><b> <a href="managepassengers.php">Manage Passengers</a></b></span></td>
     </tr><br>
     <tr>
     <td><span><b> <a href="updateuserprofile.php">Edit Profile</a></b></span></td>
     </tr><br>
	 <tr>
     <td><span><b> <a href="verify.php">Verify Ticket</a></b></span></td>
     </tr><br>
     
     
 </tr>

						

						
					</fieldset>
				</form>
			</td>
				
		</tr>


		

		<tr align="center">
			<td colspan="3">Copyright © 2021</td>
		</tr>


	</table>
</body>
</html>

