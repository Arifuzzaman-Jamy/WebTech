<!DOCTYPE html>
<html>
    <head>
	<title>Digital Train Ticketing System</title>
        <meta lang="en-us"> 
    </head>
<body>


<table border="1" cellspaceing="0px" align="center" width="900px">
		<tr height="50px">
			
		    
		    <th colspan="3">
		    	
                <a href="home.php" >Home</a>|
		    	<a href="login.php">Login</a>|
		    	<a href="registration.php">Registration</a>
		    </th>
		    
   
		   
		</tr>

		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					<fieldset>
						<legend>
							<strong>Manage Passengers</strong><br/>
							


						</legend>


<form action="welcomepage.php" method='post'  >
    <table style="width:40%" >

    <tr>
  <td><input type="submit" name="Passengers Complains" value="Passengers Complains"></td>
  <td><input type="submit" name="Passengers Data List" value="Passengers Data List"></td>
   
 </tr>