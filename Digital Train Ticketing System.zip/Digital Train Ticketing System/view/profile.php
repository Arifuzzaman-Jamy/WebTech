<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/profile.css">

</head>
<body>

<div id="header">
<h1>Digital Train Ticketing System</h1>
</div>

<div id="topnav">


<a href="home.php">Home</a>
<a href="login.php">Login</a>
<a href="registration.php">Registration</a>
 
</div>

</div>

<div class="container">
  <form action="/action_page.php">
  <div class="row">
    <div class="col-25">
      <label for="fname">First Name</label>
    </div>
    <div class="col-75">
      <input type="text" id="fname" name="firstname" placeholder="Your first name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">Last Name</label>
    </div>
    <div class="col-75">
      <input type="text" id="lname" name="lastname" placeholder="Your last name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="mobile">Mobile</label>
    </div>
    <div class="col-75">
      <input type="text" id="mobile" name="mobile" placeholder="Your mobile number..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="email">Email</label>
    </div>
    <div class="col-75">
      <input type="text" id="email" name="email" placeholder="Your email address..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="district">District</label>
    </div>
    <div class="col-75">
      <select id="district" name="district">
        <option value="Dhaka">Dhaka</option>
        <option value="Chittagong">Chittagong</option>
        <option value="Noakhali">Noakhali</option>
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="message">Message</label>
    </div>
    <div class="col-75">
      <textarea id="message" name="message" placeholder="Write something.." style="height:200px"></textarea>
    </div>
  </div>
  <div class="row">
    <input type="submit" value="Submit">
  </div>
  </form>
</div>

<div id="foot">
<b>Contact</b><br>Let us book your next trip!
<br>Bangladesh<br><br><i class="fas fa-phone"></i> Help Line No: 2021
</div>


</body>
</html>
