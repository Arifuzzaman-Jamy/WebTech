<!DOCTYPE html>
<html>
<head>
<title>Digital Train Ticketing System</title>
</head>
<body>
<?php

// define variables and set to empty values
 $ticketErr = $pinErr = $mobileErr = "";
 $ticket = $pin = $mobile = "";


 if ($_SERVER["REQUEST_METHOD"] == "POST") {  
  if (empty($_POST["ticket"])) {
    $ticketErr = "ticket required";
  } else {
    $ticket = test_input($_POST["ticket"]);
  }

  if (empty($_POST["pin"])) {
    $pinErr = "pin is required";
  } else {
    $pin = test_input($_POST["pin"]);
  }
  if (empty($_POST["mobile"])) {
    $mobileErr = "mobile is required";
  } else {
    $mobile = test_input($_POST["mobile"]);
  }
   
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
	<table border="1" cellspaceing="0px" align="center" width="900px">
		<tr height="50px">
			
		    
		    <th colspan="3">
		    	
		    	<a href="home.php" >Home</a>|
		    	<a href="login.php">Login</a>|
		    	<a href="registration.php">Registration</a>|
          
		    </th>
		    
   
		   
		</tr>

		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					<fieldset>
						<legend>
							<strong>Verify Ticket</strong><br/>
							


						</legend>

						

<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  <b>Ticket:</b><br>
  <select name="ticket" id="ticket">
  <option value="">Online Purchase</option>
  <option value="Online Purchase">Online Purchase</option>
  <option value="Counter Printed">Counter Printed</option>
</select>
<span class="error">* <?php echo $ticketErr;?></span>
<br><br>
 



Pin: <input type="number" name="pin">
  <span class="error"><?php echo $pinErr;?></span>
  <br><br>


  Mobile: <input type="number" name="mobile">
  <span class="error"><?php echo $mobileErr;?></span>
  <br><br>
  
  
       
  <input type="submit" name="Verify" value="Verify">
  
     
 
     

						
					</fieldset>
				</form>
			</td>
				
		</tr>


		

		<tr align="center">
			<td colspan="3">Copyright © 2020</td>
		</tr>


	</table>
</body>
</html>

