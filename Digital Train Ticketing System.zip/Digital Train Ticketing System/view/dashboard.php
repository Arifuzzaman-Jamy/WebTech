<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/registration.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

</head>
<body>



<div id="header">
<h1>Disital Train Ticketing System</h1>
</div>

<div id="topnav">



<a href="home.php">Home</a>
<a href="login.php">Login</a>
<a href="logout.php">Logout</a>
<a href="search.php">Search</a>
 
</div>
</div>

<div id="contact-title">
  <h1>Dashboard</h1>
</div>
<div id="contact-form">

<form action="updateuserprofile.php" method='post'  >
    <table style="width:50%" >

    <tr>
            <td>Change Username      :</td>
            <td> <input type="text" id="form-control"></td>
            
        </tr>
    
    

        <tr>
            <td>Change Password      :</td>
            <td> <input type="text" id="form-control"></td>
            
        </tr>

       

        
        <tr>
            <td>Change Email      :</td>
            <td> <input type="email" id="form-control"></td>
            
        </tr>

        <tr>
            <td>Change Mobile Number    :</td>
            <td> <input type="number" id="form-control"></td>
            
        </tr>
        
       
        

        
        
            <tr>
                <td>Change Profile Pic    :</td>
                <td>
                    <input type="file" id="form-control" name="fileToUpload" id="fileToUpload">
                    <br>
                </td>
            </tr><br><br>

            <tr>
     <td><input type="submit" id="form-control submit" name="Submit" value="Submit"></td><br>
     <td><input type="submit" id="form-control submit" name="Recent Purchase History" value="Recent Purchase History"></td><br>
     <td><input type="submit" id="form-control submit" name="Update User Profile" value="Update User Profile"></td>

    
 </tr>
						

						
					</fieldset>
				</form>

</div>

</body>
</html>
