<!DOCTYPE html>
<html>
    <head>
	<title>Digital Train Ticketing System</title>
        <meta lang="en-us"> 
    </head>
<body>


<table border="1" cellspaceing="0px" align="center" width="900px">
		<tr height="50px">
			
		    
		    <th colspan="3">
		    	
                <a href="home.php" >Home</a>|
		    	<a href="loginpage.php">Login</a>|
		    	<a href="regpage.php">Registration</a>
		    </th>
		    
   
		   
		</tr>

		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					<fieldset>
						<legend>
							<strong>Information Of Trains</strong><br/>
							


						</legend>


<form action="informoftrains.php" method='post'  >
    <table style="width:40%" >

    <tr>
  <td><input type="submit" name="Train Arriving Times" value="Train Arriving Times"></td>
  <td><input type="submit" name="List Of Trains" value="List Of Trains"></td>
   
 </tr>