<!DOCTYPE html>
<html lang="en">
<head>
<script>
    function validateform() {
     
      
      var username = document.getElementById("username").value;
var password=document.getElementById("password").value;

  

 if (username==null || username==""){  
  alert("username can't be blank");  
  return false; 
} else if(password.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
  }
  
  }
    

</script> 
<link rel="stylesheet" type="text/css" href="../css/registration.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>



<div id="header">
<h1>Digital Train Ticketing System</h1>
</div>

<div id="topnav">



<a href="home.php">Home</a>
<a href="registration.php">Registration</a>
<a href="logout.php">Logout</a>
 
</div>

<section class="main">
 
<h1>Login</h1>
 
<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
<div>
<label>User Name</label>
<input type="text" id="form_fname" name="u_name" value="" required="">
</div>
<br>
<div>
<label>Password</label>
<input type="password" id="form_password" name="u_pass" value="" required="">
</div>
<br>
    
 
<input type="submit"name="submit"value="Login">
<span style="color:red"></span>
<span><b>Or Register <a href="registration.php">here</a></b></span>

</form>
 

<?php
  if(isset($_POST['submit']))
  {     
    session_start();
    $_SESSION['name']= htmlentities( $_POST['u_name']);
    echo "<h1>Welcome".$_SESSION['u_name']."</h1>";       
    header('Location: customer.php');
     
      }
?>
</section>

<div id="foot">
<b>Contact</b><br>Let us book your next trip!
<br>Bangladesh<br><br><i class="fas fa-phone"></i> Help Line No: 2021
</div>


</body>
</html>
