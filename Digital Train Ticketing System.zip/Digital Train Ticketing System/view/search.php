<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/registration.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
    function search() {
      var search = document.getElementById("search").value;
      var type = document.querySelector('input[name = "type"]:checked');
      if (type == null) {
        alert("select type");
      } else {
        type = type.value;
        if (type == "id") {
          var numbers = /^[0-9]+$/;
          if (search.match(numbers)) {} else {
            alert("Enter Number Only!");
          }
        } else if (type == "name") {
          var letters = /^[A-Za-z ]+$/;
          if (search.match(letters)) {} else {
            alert("Character only!");
          }

        } else if (type == "Phone") {
          var numbers = /^[0-9]+$/;
          if (search.length > 8) {
            if (search.match(numbers)) {} else {
              alert("Enter Number Only!");
            }
          } else {
            alert("Number should be more than 8 digit!");;
          }

        } else if (type == "Email") {
          var em = ValidateEmail(search);
          if (em) {} else {
            alert("Invalid Email!");
          }
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {

          if (this.readyState == 4 && this.status == 200) {
            document.getElementById("mytext").innerHTML = this.responseText;
          } else {
            document.getElementById("mytext").innerHTML = this.status;
          }
        };
        xhttp.open("POST", "/MyCode/Final_Project/control/search.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("search=" + search + "&type=" + type);

      }

      // var search = document.getElementById("search").value;

    }
    function ValidateEmail(mail) {
      if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(mail)) {
        return (true)
      }
      alert("You have entered an invalid email address!")
      return (false)
    }
  </script>

</head>
<body>


<div id="header">
<h1>Digital Train Ticketing System</h1>
</div>

<div id="topnav">



<a href="home.php">Home</a>
<a href="registration.php">Registration</a>
<a href="logout.php">Logout</a>
 
</div>

<div id="contact-title">
  <h1>Search By...</h1>
</div>
<input type="text" id="search"><br><br><br>
    <input type="radio" name="type" id="radio" value="id"><b>Search by Id</b>
    <input type="radio" name="type" id="radio" value="name"><b>Search by Name</b>
    <input type="radio" name="type" id="radio" value="phone"><b>Search by Phone</b>
    <input type="radio" name="type" id="radio" value="email"><b>Search by Email</b>
    <br><br><br>
    <button id="searchbtn" onclick="search()"><b>Search</b></button><br><br><br>

    <p id="mytext"></p>

    <form action="">

    </form>


<div id="foot">
<b>Contact</b><br>Let us book your next trip!
<br>Bangladesh<br><br><i class="fas fa-phone"></i> Help Line No: 2020
</div>

</body>
</html>
