<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/registration.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

</head>
<body>


<?php

// define variables and set to empty values
$nameErr = $usernameErr =  $emailErr = $mobileErr = $passwordErr = $confirmpasswordErr = $genderErr = "";
$name = $username = $email = $mobile = $password = $confirmpassword = $gender = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["username"])) {
    $usernameErr = "Username required";
  } else {
    $username = test_input($_POST["username"]);
  }

  if (empty($_POST["mobile"])) {
    $mobileErr = "mobile number required";
  } else {
    $mobile = test_input($_POST["mobile"]);
  }

  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = test_input($_POST["password"]);
  }

  if (empty($_POST["confirmpassword"])) {
    $confirmpasswordErr = "confirmation required";
  } else {
    $confirmpassword = test_input($_POST["confirmpassword"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>



<div id="header">
  <h1>Digital Train Ticketing System</h1>
</div>

<div id="topnav">



<a href="home.php">Home</a>
<a href="login.php">Login</a>

 
</div>
</div>

<div id="contact-title">
  <h1>Registration Form</h1>
</div>
<div id="contact-form">
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" id="form-control" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="email" id="form-control" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  Username: <input type="text" id="form-control" name="username">
  <span class="error"><?php echo $usernameErr;?></span>
  <br><br>
  Mobile: <input type="number" id="form-control" name="mobile">
  <span class="error"><?php echo $mobileErr;?></span>
  <br><br>
  Password: <input type="text" id="form-control" name="password">
  <span class="error"><?php echo $passwordErr;?></span>
  <br><br>
  Confirmpassword: <input type="text" id="form-control" name="confirmpassword">
  <span class="error"><?php echo $confirmpasswordErr;?></span>
  <br><br>
 
 
 
  <b>Gender:</b><br><br>
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
  
       
  <input type="submit" id="form-control submit" name="submit" value="Sign In">
     
  <input type="reset" id="form-control submit" name="reset" value="reset">
     
					</fieldset>
				</form>
			</td>
				
		</tr>


	
</form>
</div>




<div id="foot">
<b>Contact</b><br>Let us book your next trip!
<br>Bangladesh<br><br><i class="fas fa-phone"></i> Help Line No: 2021
</div>


</body>
</html>
