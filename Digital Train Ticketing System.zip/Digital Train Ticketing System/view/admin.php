<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/admin.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>



<div id="header">
<h1>Digital Train Ticketing System</h1>
</div>

<div id="topnav">



<a href="home.php">Home</a>
<a href="registration.php">Registration</a>
<a href="logout.php">Logout</a>

</div>

<div id="contact-title">
  <h1>Admin</h1>
  <tr>
            <td>Name  :</td>
            <td>Md. Arifuzzaman Jamy</td>
        </tr><br>

        <tr>
            <td>ID  :</td>
            <td>35618</td>
        </tr><br>

        <tr>
            <td>Joining Date  :</td>
            <td>22-07-2021</td>
        </tr><br>
 
</div>
<div id="contact-form">
	


						


<form action="admin.php" method='post'  >
    <table style="width:50%" >

        
    

		<td><tr><input type="submit" name="Logout" value="Logout"></tr></td><br>
       
 <tr>

     
     <td><tr><span><b> <a href="dashboard.php">Dashboard</a></b></span></tr></td><br>
	 <td><tr><span><b> <a href="">Manage Passengers</a></b></span></tr></td><br>
	 <td><tr><span><b> <a href="updateuserprofile.php">Edit Profile</a></b></span></tr></td><br>
	 
     
 </tr>

						

						
					</fieldset>
				</form>
				</div>

<div id="foot">
<b>Contact</b><br>Let us book your next trip!
<br>Bangladesh<br><br><i class="fas fa-phone"></i> Help Line No: 2021
</div>

</body>
</html>

