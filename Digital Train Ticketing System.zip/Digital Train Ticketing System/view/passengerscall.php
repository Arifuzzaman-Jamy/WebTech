<!DOCTYPE html>
<html>
    <head>
	<title>Digital Train Ticketing System</title>
        <meta lang="en-us"> 
    </head>
<body>


<table border="1" cellspaceing="0px" align="center" width="900px">
		<tr height="50px">
			
		    
		    <th colspan="3">
		    	
                <a href="home.php" >Home</a>|
		    	<a href="login.php">Login</a>|
		    	
		    </th>
		    
   
		   
		</tr>

		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					<fieldset>
						<legend>
							<strong>Passengers Calls</strong><br/>
							


						</legend>


<form action="informoftrains.php" method='post'  >
    <table style="width:40%" >

    <tr>
  <td><input type="submit" name="Incoming Call list" value="Incoming Call list"></td>
 
   
 </tr>