<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/registration.css">

</head>
<body>


<div id="header">
<h1>Digital Train Ticketing System</h1>
</div>

<div id="topnav">



<a href="home.php">Home</a>
<a href="registration.php">Registration</a>
<a href="logout.php">Logout</a>
 
</div>

<div id="contact-title">
  <h1>User Profile </h1>
</div>
<div id="contact-form">
<form action="updateuserprofile.php" method='post'  >
    <table style="width:50%" >
        <tr>
            <td>Passenger Name      :</td>
            <td> <input type="text" required></td>
            
        </tr><br>
 
        
        <tr>
            <td>Post Code      :</td>
            <td> <input type="number" required></td>
            
        </tr><br>
        
       
        <tr>
            <td>Address  :</td>
            <td><input type="text" required></td>
        </tr><br>
 
        
        <tr>
                <td>Date of Birth</td>
                <td><input type="date" id="join" name="join"></td>
            </tr><br>
 
            <tr><td><table >
            <tr>
                <b> Gender</b><br>
                <input type="radio" id="male" name="gender" value="male">
                <label for="male">Male</label>
                <input type="radio" id="female" name="gender" value="female">
                <label for="female">Female</label>
                <input type="radio" id="other" name="gender" value="other">
                <label for="other">Other</label>
            </tr><br>
 
            <tr>
                <td><label for="identification number">Identification Number:</label></td>
                <td>
                    <select name="identification number" id="identification number">
                        
                        <option value="National ID">National ID</option>
                        <option value="Birth Certificate">Birth Certificate</option>
                       
                    </select>
                   
                </td>
            </tr>
           
        </table></td></tr><br>
 
       
          
            <td><input type="number"></td><br><br>
        
          
      
 
       
 <tr>
     <td><input type="submit" name="Update Profile" value="Update Profile"></td<br><br>
     
 </tr>			
                </form>
                
</div>



</body>
</html>
