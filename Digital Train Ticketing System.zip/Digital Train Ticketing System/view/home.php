<!DOCTYPE html>
<html>
<head>
<title>Digital Train Ticketing System</title>
</head>
<body>
	<table border="1" cellspaceing="0px" align="center" width="900px">
		<tr height="50px">
			
		    <th colspan="5">
		    	
		    	<a href="home.php" >Home</a>|
		    	<a href="login.php">Login</a>|
		    	<a href="registration.php">Registration</a>|
				<a href="manager.php" >Manager</a>|
				<a href="stationmaster.php" >Station Master</a>|
		    </th>
		    
   
		   
		</tr>

		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					
						<legend>
							<strong>Public Home</strong><br/>
							


						</legend>      
 
     
         <h1>WELCOME TO DIGITAL TRAIN TICKETING SYSTEM</h1>
      
 				
					
				</form>
			</td>
				
		</tr>


		

		<tr align="center">
			<td colspan="3">Copyright  2021</td>
		</tr>


	</table>
</body>
</html>

