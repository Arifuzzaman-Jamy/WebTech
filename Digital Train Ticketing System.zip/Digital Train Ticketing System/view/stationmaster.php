<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="station.css">
<title>Digital Train Ticketing System</title>
</head>
<body>

	
		
                <div class ="topnav">
		    	<a href="home.php" >Home</a>|
		    	<a href="login.php">Login</a>|
                <a href="registration.php">Registration</a>
                <a href="p.php">Passenger</a>

</div>
		   
		    
   
		   
		</tr>

		<tr height="100px">
			<td colspan="3" style="font-size: 13">
				<form action="" method="POST">
					<fieldset>
						<legend>
							<strong>Station Master</strong><br/>
							


						</legend>

						


<form action="stationchange.php" method='post'  >
    <table style="width:50%" >
        
    <tr>
            <td>Name  :</td>
            <td>AbC</td>
        </tr>

        <tr>
            <td>ID  :</td>
            <td>25431351</td>
        </tr>

        <tr>
            <td>Joining Date  :</td>
            <td>21-06-2021</td>
        </tr>
       
 <tr>
 <tr>
     
 <tr>
     <td><span><b> <a href="Passengersmassage.php">Passenger Masseges</a></b></span></td>
     </tr><br>
     <tr>
     <td><span><b> <a href="informoftrains.php">Information Of Trains</a></b></span></td>
     </tr><br>
	 <tr>
     <td><span><b> <a href="Passengerscall.php">Passengers Calls</a></b></span></td>
     </tr><br>
     <tr>
     <td><span><b> <a href="updateuserprofile.php">Edit Profile</a></b></span></td>
     </tr><br>
     
 </tr>

						

						
					</fieldset>
				</form>
			</td>
				
		</tr>


		

		<tr align="center">
			<td colspan="3">Copyright © 2021</td>
		</tr>


	</table>
</body>
</html>

