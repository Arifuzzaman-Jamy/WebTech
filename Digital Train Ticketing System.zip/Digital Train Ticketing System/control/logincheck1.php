<?php
	
	require_once('../model/userService.php');

	if(isset($_POST['submit'])){

		//declaration
		$uname 	= $_POST['u_name'];
		$pass 	= $_POST['u_pass'];

		//validation
		if($uname == ""){
			
			header('location: ../view/login.php?msg=null_username');

		}else if(empty($pass)){
			
			header('location: ../view/login.php?msg=null_password');

		}else{

			// $conn = getConnection();
			// $sql = "select * from user where username='$uname' and password='$pass'";
			// $result = mysqli_query($conn, $sql);
			// $row = mysqli_fetch_assoc($result);

			$user = ['u_name'=> $uname, 'u_pass'=>$pass];
			$status = validateUser($user);

			if($status){
				setcookie('isValid', 'true', time()+3600, '/');
				header('location: ../view/customer.php');
			}else{
				header('location: ../view/login.php?msg=invalid_user');
			}
		}
	}else{
		header('location: login.php');
	}
?>