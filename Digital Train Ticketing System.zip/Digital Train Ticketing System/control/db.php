<?php
class DataAccess{
   public $conn;

   function __construct() 
   {
    $this->conn = new mysqli("localhost", "root", "", "ticket_system");
   }

   function GetData($sqlQuery)
   {
      $result=$this->conn->query($sqlQuery);
      if(!empty($result->num_rows))
      {
         return $result;         
      }
   }

   
   function __destruct()
   {
      $this->conn->close();
   }

}
?>