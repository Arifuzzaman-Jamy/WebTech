
<?php
require_once('../view/registration.php');

// define variables and set to empty values
$nameErr = $usernameErr =  $emailErr = $mobileErr = $passwordErr = $confirmpasswordErr = $genderErr = "";
$name = $username = $email = $mobile = $password = $confirmpassword = $gender = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["username"])) {
    $usernameErr = "Username required";
  } else {
    $username = test_input($_POST["username"]);
  }

  if (empty($_POST["mobile"])) {
    $mobileErr = "mobile number required";
  } else {
    $mobile = test_input($_POST["mobile"]);
  }

  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = test_input($_POST["password"]);
  }

  if (empty($_POST["confirmpassword"])) {
    $confirmpasswordErr = "confirmation required";
  } else {
    $confirmpassword = test_input($_POST["confirmpassword"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
