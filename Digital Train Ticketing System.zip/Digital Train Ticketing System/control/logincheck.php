<?php
 require_once('../view/login.php');


if($_SERVER["REQUEST_METHOD"]=="POST")
 
{
$user_name=validate($_POST["u_name"]);
$password=validate($_POST["u_pass"]);
 
echo "user_name: ".$user_name."<br/>";
echo "password: ".$password."<br/>";
 
}
function validate($data)
{
    $data=trim($data);
    $data=stripcslashes($data);
    $data=htmlspecialchars($data);
    return $data;
}
?>
<?php
  if(isset($_POST['submit']))
  {     
    session_start();
    $_SESSION['name']= htmlentities( $_POST['u_name']);
    echo "<h1>Welcome".$_SESSION['u_name']."</h1>";       
    header('Location: homepage.php');
     
      }
?>