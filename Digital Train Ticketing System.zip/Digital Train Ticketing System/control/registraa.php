<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/registra.css">
 
</head>
<body>




 
<div id="header">
  <h1>Disital Train Ticketing System</h1>
</div>
 
<div id="topnav">


 
<a href="home.php">Home</a>
<a href="login.php">Login</a>
<a href="logout.php">Logout</a>
 
</div>
</div>
 
<div id="contact-title">
  <h1>Registration Form</h1>
</div>
<div id="contact-form">
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" id="form-control" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="email" id="form-control" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  Username: <input type="text" id="form-control" name="username">
  <span class="error"><?php echo $usernameErr;?></span>
  <br><br>
  Mobile: <input type="number" id="form-control" name="mobile">
  <span class="error"><?php echo $mobileErr;?></span>
  <br><br>
  Password: <input type="text" id="form-control" name="password">
  <span class="error"><?php echo $passwordErr;?></span>
  <br><br>
  Confirmpassword: <input type="text" id="form-control" name="confirmpassword">
  <span class="error"><?php echo $confirmpasswordErr;?></span>
  <br><br>
 
 
 
  <b>Gender:</b><br><br>
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
  
       
  <input type="submit" id="form-control submit" name="submit" value="Sign In">
     
  <input type="reset" id="form-control submit" name="reset" value="reset">
     
                    </fieldset>
                </form>
            </td>
                
        </tr>
 
    
</form>
</div>



 
<div id="foot">


 
<a href="">copyright @ 2021</a>
 
</div>
 
</body>
</html>