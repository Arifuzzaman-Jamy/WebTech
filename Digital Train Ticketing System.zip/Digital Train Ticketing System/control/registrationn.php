<!DOCTYPE html>
<html lang="en">
<head>
<script>
    function validateform() {
     
      var name = document.getElementById("name").value;
      var username = document.getElementById("username").value;
var password=document.getElementById("password").value;
var confirmpassword=document.getElementById("confirmpassword").value; 
var email=document.getElementById("email").value; 

  
if (name==null || name==""){  
  alert("Name can't be blank");  
  return false;  
}
else if (username==null || username==""){  
  alert("username can't be blank");  
  return false; 
} else if(password.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
  }
  else if(confirmpassword.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
  }
  else if (email==null || email==""){  
  alert("E-mail can't be blank");  
  return false;  
  
    }
   
  }
    

</script> 
<link rel="stylesheet" type="text/css" href="../css/registra.css">
 
</head>
<body>




 
<div id="header">
  <h1>Disital Train Ticketing System</h1>
</div>
 
<div id="topnav">


 
<a href="home.php">Home</a>
<a href="login.php">Login</a>
<a href="logout.php">Logout</a>
 
</div>
</div>
 
<div id="contact-title">
  <h1>Registration Form</h1>
</div>
<div id="contact-form">

<form name="registrationn" method="post" action="registrationn.php" onsubmit="return validateform()" >  
Name: <input type="text" id="name" name="name"><br/>
Username: <input type="text" id="username" name="username"><br/>   
Password: <input type="password" id="password" name="password"><br/>
Confirm Password: <input type="password" id="confirmpassword" name="confirmpassword"><br/>
E-mail: <input type="email" id="email" name="email"><br/>

<input type="submit" value="register">

     
                    </fieldset>
                </form>
            </td>
                
        </tr>
 
    
</form>
</div>



 
<div id="foot">


 
<a href="">copyright @ 2021</a>
 
</div>
 
</body>
</html>