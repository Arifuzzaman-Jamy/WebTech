<?php
include('db.php');
$newCon=new DataAccess();
$searchText=$_POST['search'];
$type=$_POST['type'];

$row="";



if($type=="id")
{
    $getquery="Select * from customer where id='".$searchText."'";
}
else if($type=="name")
{
    $getquery="Select * from customer where Name='".$searchText."'";
}
else if($type=="email")
{
    $getquery="Select * from customer where Email='".$searchText."'";
}
else if($type=="phone")
{
    $getquery="Select * from customer where Telephone='".$searchText."'";
}

$result=$newCon->GetData($getquery);

if (!empty($result->num_rows))
{
    $row = $result->fetch_assoc();

      ?>
          
      <table>
      <tr>
      <td><label for="">Name :</label></td>


      <td><label for=""><?php echo $row['Name']?></label></td>
      </tr>

      <tr>
      <td><label for="">Address :</label></td>

      <td><label for=""><?php echo $row['Address']?></label></td>
      </tr>

      <tr>
      <td><label for="">Email :</label></td>

      <td><label for=""><?php echo $row['Email']?></label></td>
      </tr>

      <tr>
      <td><label for="">Password :</label></td>

      <td><label for=""><?php echo $row['Password']?></label></td>
      </tr>

      <tr>
      <td><label for="">Telephone :</label></td>

      <td><label for=""><?php echo $row['Telephone']?></label></td>
      </tr>

            <tr>
                <td><label for="">District :</label></td>
                <td><label for=""><?php echo $row['District']?></label></td>
            </tr>     
      </table>
      <?php
} 
else
{
    echo "No data Found";
}

?>
      
